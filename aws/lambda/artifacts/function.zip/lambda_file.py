from __future__ import division

def lambda_handler(event, context):
   return {
      "Example file."
   }  