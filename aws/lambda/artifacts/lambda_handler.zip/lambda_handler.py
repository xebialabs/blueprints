import json

def lambda_handler(event, context):
    # TODO implement
    return {
        'statusCode': 200,
        'body': json.dumps("This AWS Lambda Function deployed by XL Deploy!")
    }
